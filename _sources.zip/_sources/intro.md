# University of Manchester AI WebService Catalogue


```{tableofcontents}
```
